
# Groceteria

An online grocery store bulid using html,css and javascript


## Features

- Designed with eye catching color palettes
- astounding animations to enhance the UI experience
- Integrated with present-day features to make website Modernized


## Live Link

https://groceteria.netlify.app/

## Authors

- [@cherish](https://github.com/cherish2003)


## Feedback

If you have any feedback, please reach out to us at saicherish90@gmail.com
